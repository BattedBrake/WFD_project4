<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Dokter;
use App\Models\Jadwal;
use App\Models\Reservasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
    // =============================================
    // DASHBOARD
    // =============================================
    public function dashboard()
    {
        $totalDokter       = Dokter::count();
        $totalPasien       = User::where('role', 'pasien')->count();
        $reservasiHariIni  = Reservasi::whereHas('jadwal', fn($q) => $q->whereDate('tanggal', today()))->count();
        $reservasiPending  = Reservasi::where('status', 'Pending')->count();
        $reservasiTerbaru  = Reservasi::with(['user', 'jadwal.dokter.user'])->latest()->take(10)->get();
        $dokterAktif       = Dokter::with('user')->take(6)->get();

        return view('admin.dashboard', compact(
            'totalDokter', 'totalPasien', 'reservasiHariIni',
            'reservasiPending', 'reservasiTerbaru', 'dokterAktif'
        ));
    }

    // =============================================
    // KELOLA DOKTER
    // =============================================
    public function dokterIndex(Request $request)
    {
        $query = Dokter::with('user');

        if ($request->search) {
            $query->whereHas('user', fn($q) => $q->where('nama', 'like', '%' . $request->search . '%'));
        }
        if ($request->spesialisasi) {
            $query->where('spesialisasi', $request->spesialisasi);
        }

        $dokters          = $query->paginate(10);
        $spesialisasiList = Dokter::distinct()->pluck('spesialisasi');

        return view('admin.dokter.index', compact('dokters', 'spesialisasiList'));
    }

    public function dokterCreate()
    {
        return view('admin.dokter.form');
    }

    public function dokterStore(Request $request)
    {
        $request->validate([
            'nama'         => 'required|string|max:255',
            'email'        => 'required|email|unique:users,email',
            'password'     => 'required|min:8',
            'spesialisasi' => 'required|string|max:100',
            'foto'         => 'nullable|image|max:2048',
        ]);

        // Buat user dengan role dokter
        $user = User::create([
            'nama'     => $request->nama,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
            'phone'    => $request->phone,
            'role'     => 'dokter',
        ]);

        // Upload foto jika ada
        $fotoPath = null;
        if ($request->hasFile('foto')) {
            $fotoPath = $request->file('foto')->store('dokter', 'public');
        }

        Dokter::create([
            'user_id'      => $user->user_id,
            'spesialisasi' => $request->spesialisasi,
            'deskripsi'    => $request->deskripsi,
            'foto'         => $fotoPath,
        ]);

        return redirect()->route('admin.dokter.index')->with('success', 'Dokter berhasil ditambahkan.');
    }

    public function dokterShow($id)
    {
        $dokter = Dokter::with(['user', 'jadwals.reservasis'])->findOrFail($id);
        return view('admin.dokter.show', compact('dokter'));
    }

    public function dokterEdit($id)
    {
        $dokter = Dokter::with('user')->findOrFail($id);
        return view('admin.dokter.form', compact('dokter'));
    }

    public function dokterUpdate(Request $request, $id)
    {
        $dokter = Dokter::with('user')->findOrFail($id);

        $request->validate([
            'nama'         => 'required|string|max:255',
            'email'        => 'required|email|unique:users,email,' . $dokter->user_id . ',user_id',
            'spesialisasi' => 'required|string|max:100',
            'foto'         => 'nullable|image|max:2048',
        ]);

        $dokter->user->update([
            'nama'  => $request->nama,
            'email' => $request->email,
            'phone' => $request->phone,
        ]);

        if ($request->hasFile('foto')) {
            if ($dokter->foto) Storage::disk('public')->delete($dokter->foto);
            $dokter->foto = $request->file('foto')->store('dokter', 'public');
        }

        $dokter->spesialisasi = $request->spesialisasi;
        $dokter->deskripsi    = $request->deskripsi;
        $dokter->save();

        return redirect()->route('admin.dokter.index')->with('success', 'Data dokter berhasil diperbarui.');
    }

    public function dokterDestroy($id)
    {
        $dokter = Dokter::with('user')->findOrFail($id);

        if ($dokter->foto) Storage::disk('public')->delete($dokter->foto);
        $dokter->user->delete(); // cascade delete dokter record juga

        return redirect()->route('admin.dokter.index')->with('success', 'Dokter berhasil dihapus.');
    }

    // =============================================
    // KELOLA JADWAL
    // =============================================
    public function jadwalIndex(Request $request)
    {
        $query = Jadwal::with(['dokter.user', 'reservasis']);

        if ($request->dokter_id) {
            $query->where('dokter_id', $request->dokter_id);
        }
        if ($request->tanggal) {
            $query->whereDate('tanggal', $request->tanggal);
        }

        $jadwals = $query->orderBy('tanggal', 'desc')->paginate(10);
        $dokters = Dokter::with('user')->get();

        return view('admin.jadwal.index', compact('jadwals', 'dokters'));
    }

    public function jadwalCreate()
    {
        $dokters = Dokter::with('user')->get();
        return view('admin.jadwal.form', compact('dokters'));
    }

    public function jadwalStore(Request $request)
    {
        $request->validate([
            'dokter_id' => 'required|exists:dokters,dokter_id',
            'tanggal'   => 'required|date|after_or_equal:today',
            'start'     => 'required',
            'end'       => 'required|after:start',
            'kuota'     => 'required|integer|min:1',
        ]);

        Jadwal::create($request->only(['dokter_id', 'tanggal', 'start', 'end', 'kuota']));

        return redirect()->route('admin.jadwal.index')->with('success', 'Jadwal berhasil ditambahkan.');
    }

    public function jadwalEdit($id)
    {
        $jadwal  = Jadwal::findOrFail($id);
        $dokters = Dokter::with('user')->get();
        return view('admin.jadwal.form', compact('jadwal', 'dokters'));
    }

    public function jadwalUpdate(Request $request, $id)
    {
        $jadwal = Jadwal::findOrFail($id);

        $request->validate([
            'dokter_id' => 'required|exists:dokters,dokter_id',
            'tanggal'   => 'required|date',
            'start'     => 'required',
            'end'       => 'required',
            'kuota'     => 'required|integer|min:1',
        ]);

        $jadwal->update($request->only(['dokter_id', 'tanggal', 'start', 'end', 'kuota']));

        return redirect()->route('admin.jadwal.index')->with('success', 'Jadwal berhasil diperbarui.');
    }

    public function jadwalDestroy($id)
    {
        Jadwal::findOrFail($id)->delete();
        return redirect()->route('admin.jadwal.index')->with('success', 'Jadwal berhasil dihapus.');
    }

    // =============================================
    // KELOLA RESERVASI
    // =============================================
    public function reservasiIndex(Request $request)
    {
        $query = Reservasi::with(['user', 'jadwal.dokter.user']);

        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->whereHas('user', fn($q2) => $q2->where('nama', 'like', '%' . $request->search . '%'))
                  ->orWhereHas('jadwal.dokter.user', fn($q2) => $q2->where('nama', 'like', '%' . $request->search . '%'));
            });
        }
        if ($request->status) {
            $query->where('status', $request->status);
        }
        if ($request->tanggal) {
            $query->whereHas('jadwal', fn($q) => $q->whereDate('tanggal', $request->tanggal));
        }

        $reservasis = $query->latest()->paginate(15);

        return view('admin.reservasi.index', compact('reservasis'));
    }

    public function reservasiShow($id)
    {
        $reservasi = Reservasi::with(['user', 'jadwal.dokter.user'])->findOrFail($id);
        return view('admin.reservasi.show', compact('reservasi'));
    }

    public function reservasiDestroy($id)
    {
        Reservasi::findOrFail($id)->delete();
        return redirect()->route('admin.reservasi.index')->with('success', 'Reservasi berhasil dihapus.');
    }

    // =============================================
    // KELOLA USER
    // =============================================
    public function userIndex(Request $request)
    {
        $query = User::query();

        if ($request->search) {
            $query->where(fn($q) =>
                $q->where('nama', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%')
            );
        }
        if ($request->role) {
            $query->where('role', $request->role);
        }

        $users = $query->latest()->paginate(15);

        return view('admin.user.index', compact('users'));
    }

    public function userEdit($id)
    {
        $user = User::findOrFail($id);
        return view('admin.user.edit', compact('user'));
    }

    public function userUpdate(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'nama'  => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $id . ',user_id',
            'role'  => 'required|in:admin,dokter,pasien',
            'phone' => 'nullable|string|max:20',
        ]);

        $user->update($request->only(['nama', 'email', 'role', 'phone']));

        return redirect()->route('admin.user.index')->with('success', 'Data user berhasil diperbarui.');
    }

    public function userDestroy($id)
    {
        $user = User::findOrFail($id);

        // Cegah admin hapus dirinya sendiri
        if ($user->user_id === auth()->id()) {
            return back()->with('error', 'Anda tidak dapat menghapus akun sendiri.');
        }

        $user->delete();
        return redirect()->route('admin.user.index')->with('success', 'User berhasil dihapus.');
    }
}
